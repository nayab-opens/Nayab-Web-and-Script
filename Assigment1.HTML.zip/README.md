W3 Schools HTML BASIC , W3 Schools Wrote it  : 
https://www.w3schools.com/

Youtube:
https://www.youtube.com/watch?v=UqHILyzcULE&t=1904s
https://www.youtube.com/watch?v=V49fGLgM4WE
https://www.youtube.com/watch?v=fZm4gJDY_zY&t=2275s
https://www.youtube.com/watch?v=RroDdybvu5s&t=1299s
https://www.youtube.com/watch?v=0YFrGy_mzjY&t=353s 
https://www.youtube.com/watch?v=-Yw9gBHE60E

Website Called Diagonal Color Gradients: 
showed how to do linrar Gradients 
https://codepen.io/hylobates-lar/pen/qBbQeON

Logo: 
https://boxicons.com/?query=i

Slider: 
https://www.sliderrevolution.com/resources/css-animated-background/




